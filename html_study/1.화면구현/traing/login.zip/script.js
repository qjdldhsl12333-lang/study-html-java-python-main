// 1. 데이터 정의 (이전과 동일)
const accounts = [
    {
        name: "봉하운",
        age: 29,
        address: ["경기도", "부천시", "원미로 13-1"],
        id: "qjdldhsl123",
        password: "gkdnsqwer1234"
    },
    {
        name: "김재벌",
        age: 30,
        address: ["인천광역시", "구월동"],
        id: "woqjf123",
        password: "woqjf123123"
    },
    {
        name: "여준협",
        age: 28,
        address: ["인천광역시", "구월동"],
        id: "wnsguq123",
        password: "wnsguq123123"
    }
];

// 2. DOM 요소 선택
const userIdInput = document.getElementById('userId');
const userPasswordInput = document.getElementById('userPassword');
const loginButton = document.getElementById('loginButton');
const messageArea = document.getElementById('messageArea');

// 3. 메시지 표시 함수
function displayMessage(message, isSuccess) {
    messageArea.textContent = message;
    // 기존 클래스 제거 후 성공/실패에 따라 클래스 추가 (CSS 스타일 적용용)
    messageArea.classList.remove('success', 'error');
    if (isSuccess) {
        messageArea.classList.add('success');
    } else {
        messageArea.classList.add('error');
    }
    messageArea.style.display = 'block'; // 숨겨져 있던 메시지 영역 보이게 함
}

// 4. 로그인 처리 함수
function handleLogin() {
    const inputId = userIdInput.value;
    const inputPassword = userPasswordInput.value;

    const user = accounts.find(account => account.id === inputId);

    if (!user) {
        displayMessage("❌ 로그인 실패: 존재하지 않는 아이디입니다.", false);
        return;
    }

    if (user.password === inputPassword) {
        // 로그인 성공 시 요구사항대로 메시지 출력
        displayMessage(`✅ 로그인 완료! 어서오세요 ${user.name}님.`, true);
    } else {
        displayMessage("❌ 로그인 실패: 비밀번호가 올바르지 않습니다.", false);
    }
}

// 5. 이벤트 리스너 추가
// 버튼 클릭 시 handleLogin 함수 실행
loginButton.addEventListener('click', handleLogin);
